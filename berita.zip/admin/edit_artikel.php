<?php 
error_reporting(E_ALL);
include('koneksi.php');
//include('login_session.php');
$title = 'Data Artikel';
if (isset($_POST['submit'])) { 
$id= $_POST['id'];
$judul =$_POST['tittle'];
$kategori= $_POST['kategori'];
$content =$_POST['content'];
$tanggal =$_POST['tanggal'];
$file_gambar=$_FILES['file_gambar'];
$gambar = null;

if($file_gambar['error'] ==0){
	$file_name= str_replace('','_',$file_gambar['name']);
	$destination= dirname(__FILE__).'/gambar/'.$file_name;
	if(move_uploaded_file($file_name['tmp_name'], $destination))
	{
		$gambar='gambar/'.$file_name;
	}
}

$sql= 'UPDATE berita SET ';
$sql .= "tittle='{$judul}', id_kategori ='{$kategori}', content='{$content}', tanggal='{$tanggal}' ";
if (!empty($gambar))
	$sql .= ", gambar='{$gambar}' ";
	$sql .= "WHERE id='{$id}' ";
	$result = mysqli_query($conn, $sql);
	if (!$result)die(mysqli_error($conn));
	header ('location: berita.php');

}

$id=$_GET['id'];
$sql =" SELECT * From berita WHERE id = '{$id}' ";
$result = mysqli_query($conn, $sql);
if (!$result)die('Error:Data Tidak Tersedia');
$data = mysqli_fetch_array($result);

function is_select($var, $val)  {
	if($var == $val ) return 'selected="selected"';
	return false;
}
include ('header.php');
include ('sidebar.php');

?>

<div class="content_a">
	<div class="daftar">
		<div class="main">
			<h2> Edit Artikel</h2>
			<form class="" action="edit_artikel.php" method="post" enctype="multipart/form-data" />
				<div class="input">
					<input type="text" name="tittle"  value="<?php echo $data['tittle']; ?>"  />
				</div>

				<div class="input">
					<label>Kategori</label>
					<select name="kategori">
						<?php 
						include_once('koneksi.php');
						$sql =' SELECT * From kategori';
						$result = mysqli_query($conn, $sql);
						?>

						<?php while ($row=mysqli_fetch_array($result)): ?>
							<option value="<?php echo $row['id_kategori'];?>"> <?php echo $row['nm_kategori'];?></option>
						<?php endwhile; ?>
					</select>
					</div>

					<div class="input">
						<textarea type="text" name="content" > <?php echo $data['content']; ?> </textarea>
					</div>

					<div class="input">
					<label> Tanggal</label>
					<input type="date" name="tanggal" value="<?php echo date("Y-m-d", strtotime($data['tanggal']));?>" />
					</div>


					<div class="input">
						<label>File Gambar</label>
						<input type="file" name="file_gambar" />
					</div>

					<div class="submit">
						<input type="hidden" name="id" value="<?php echo $data['id']; ?> " />
						<input type="submit" name="submit" class="btn btn-large" value="Edit" />
					</div>

			</form>
		</div>
	</div>
</div>
<?php 
include_once ('footer.php');
?>