<?php
include_once 'koneksi.php';
$title ='user';
$sql='SELECT * FROM admin';
$result = mysqli_query($conn, $sql);

include('header.php');
include('sidebar.php');
?>

<div class="content_a">
	<div class="daftar">
	<div class="main">
		<?php echo '<a href="form_user.php" class="btn btn-large" > Tambah User </a>'; ?>
		<table>
			<th> Nama Admin </th>
			<th> Username</th>
			<th> Password</th>
	
			<?php while ($row =mysqli_fetch_array($result)):?> 
			<tr>
				<td> <?php echo $row['nama_admin']; ?></td>
				<td> <?php echo $row['username']; ?></td>
				<td><?php echo $row['password']; ?></td>
			</tr>

		<?php endwhile; ?>
		</table>
<hr>
</div>
</div>
</div>
<?php 
include_once 'footer.php' ?>