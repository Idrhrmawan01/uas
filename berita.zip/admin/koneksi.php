<?php
$host ="Localhost";
$user ="root";
$pass ="";
$db ="berita";

$conn =mysqli_connect($host,$user,$pass,$db);
	
?>