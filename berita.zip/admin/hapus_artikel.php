<?php
include_once 'koneksi.php';
//include('login_session.php');

$id = $_GET['id'];
$sql = "DELETE FROM berita WHERE id= '{$id}'";
$result =mysqli_query($conn, $sql);
header('location: berita.php');
?>