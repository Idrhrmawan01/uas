<?php
include ('login_session.php');

$title = 'Data Artikel';
include_once 'koneksi.php';
$sql = 'SELECT b.id, b.id_kategori, b.gambar, b.tittle,k.nm_kategori,
				b.content,
				b.tanggal	
			FROM berita b
			JOIN kategori k on b.id_kategori=k.id_kategori 
			';

		$sql_count = " SELECT COUNT(*) FROM berita";
		if (isset($sql_where)) {
			$sql .=$sql_where;
			$sql_count .= $sql_where;
		}
		$result_count = mysqli_query($conn, $sql_count);
		$count = 0;
		if ($result_count) {
			$r_data = mysqli_fetch_row($result_count);
			$count = $r_data[0];
		}

		$per_page=4;
		$num_page = ceil($count / $per_page);
		$limit = $per_page;
		if (isset($_GET['page'])) {
			$page = $_GET['page'];
			$offset = ($page - 1) * $per_page;

		} else {
			$offset = 0;
			$page = 1;
		}

		$sql .= " LIMIT {$offset}, {$limit}";
		$result = mysqli_query($conn, $sql);


		include 'header.php';
		include 'sidebar.php';
		?>
		<div class="content_b">
			<div class="main">
				<?php echo '<a href="tambah.php" class="btn btn-large" > Tambah Artikel </a>'; ?>
				<?php
				if ($result):
				?>
				<table>
					<tr> 
						<th>Gambar</th>
						<th>Tittle</th>
						<th>Kategori</th>
						<th>Content</th>
						<th>Tanggal</th>
						<th>Action</th>
					</tr>
					<?php while($row = mysqli_fetch_array($result)): ?>
					<tr>
						<td> <?php echo "<img src=\"{$row['gambar']}\" />"; ?> </td>
						<td> <?php echo $row['tittle']; ?></td>
						<td> <?php echo $row['nm_kategori']; ?></td>
						<td><?php echo $row['content']; ?></td>
						<td><?php echo date("j F Y", strtotime($row['tanggal'])); ?> </td>
						<td class="center">
							<a class="btn btn-default" href="edit_artikel.php?id=<?php echo $row['id'];?>"> Edit </a>
							<a class="btn btn-alert" onclick="return confirm('Yakin akan menghapus data?');" 
								href="hapus_artikel.php?id=<?php echo $row['id'];?>"> Delete </a>
						</td>
					</tr>
				<?php endwhile; ?>
				</table>
				<ul class="pagination">
      <?php
            if ($page == 1) { // Jika page adalah pake ke 1, maka disable link PREV
            ?>

                <li class="disabled"><a href="#">&laquo;</a></li>
            <?php
            } else { // Jika buka page ke 1
                $link_prev = ($page > 1) ? $page - 1 : 1;
            ?>

             <li><a href="view.php?page=<?php echo $page-1;?>">&laquo;</a></li>


            <?php
            }
            ?>

       <?php for ($i=1; $i <=$num_page; $i++) {
         $link = "?page={$i}";
         if (!empty($q)) $link .= "&q={$q}";
         $class = ($page == $i ? 'active' : '');
         echo "<li><a class=\"{$class}\" href=\"{$link}\">{$i}</a></li>";
                } ?>
                <?php
            // Jika page sama dengan jumlah page, maka disable link NEXT nya
            // Artinya page tersebut adalah page terakhir
            if ($page == $num_page) { // Jika page terakhir
            ?>
                <li class="disabled"><a href="#">&raquo;</a></li>

            <?php
            } else { // Jika bukan page terakhir
                $link_next = ($page < $num_page) ? $page + 1 : $num_page;
            ?>
               <li><a href="view.php?page=<?php echo $page+1;?>">&raquo;</a></li>

            <?php
            }
            ?>

              </ul>
			<?php endif; ?>
			</div>
		</div>
		<?php include_once 'footer.php'; ?>


