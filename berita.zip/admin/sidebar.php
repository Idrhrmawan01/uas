<!-- Membuat sidebar -->
		<div class="sidebar">
			<div class="widget-box">
				<h3 class="title"> Menu</h3>
			<ul>
				<li><a href="kategori.php"> Data Kategori</a></li>
				<li><a href="berita.php"> Data Artikel</a></li>
				<li><a href="user.php"> Manage User</a></li>
				<li><a href="komentar.php"> Manage Komentar</a></li>
				<li><a href="..\index.php"> Logout</a></li>
			</ul>
		</div>

		</div>