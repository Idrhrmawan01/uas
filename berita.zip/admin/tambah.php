<?php 
include_once 'koneksi.php';
error_reporting(E_ALL);

if (isset($_POST['submit'])) {
	$judul =$_POST['tittle'];
	$kategori =$_POST['kategori'];
	$content =$_POST['content'];
	$tanggal =$_POST['tanggal'];
	$file_gambar=$_FILES['file_gambar'];
	$gambar = null;

if ($file_gambar['error'] ==0) {
	$filename = str_replace('','_', $file_gambar['name']);
	$destination = dirname(__FILE__).'/image/'.$filename;
	if(move_uploaded_file($file_gambar['tmp_name'],$destination))
	{
		$gambar='image/'.$filename;
	}

}
	$sql = 'INSERT INTO berita (tittle,id_kategori,content,tanggal,gambar) ';
	$sql .= "VALUE ('{$judul}','{$kategori}','{$content}','{$tanggal}','{$gambar}')";
	$result = mysqli_query($conn, $sql);
	if(!$result) {
		die(mysqli_error($conn));
	}
	header('location: berita.php');
}
include('header.php');
include('sidebar.php');
?>
<div class="content_a">
	<div class="daftar">
	<div class="main">
<h2>Tambah Artikel</h2>
<form method="post" action="?mod=admin/tambah" enctype="multipart/form-data">
	<div class="input">
		<input type="text" name="tittle" placeholder="Judul Artikel" />
	</div>
	<div class="input">
		<label> Kategori</label>
					<select name="kategori">
						<?php
						include_once 'koneksi.php';
						$sql = 'SELECT * FROM kategori';
						$result = mysqli_query($conn, $sql);
						?>
					<?php while ($row = mysqli_fetch_array($result)): ?>
						<option value="<?php echo $row ['id_kategori'];?>"><?php echo $row['nm_kategori'];?> </option>	
					<?php endwhile; ?>
				</select>
				</div>
	<div class="input">
		<textarea type="text" name="content" cols="100" rows="20" placeholder="Isi Artikel"></textarea>
	</div>
	<div class="input">
		<label>Tanggal</label>
		<input type="date" name="tanggal" />
	</div>
	<div class="input">
					<label>File Gambar</label>
					<input type="file" name="file_gambar">
				</div>
	<div class="submit">
		<input type="submit" name="submit" class="btn btn-large" value="simpan" />
	</div>
	</div>
</div>
</div>
</form>
<?php
include('footer.php');
?>
