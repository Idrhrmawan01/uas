<?php 
include_once 'koneksi.php';
error_reporting(E_ALL);


$title = 'Data Komentar';
include_once 'koneksi.php';
$sql = 'SELECT * FROM komentar';
$result = mysqli_query($conn, $sql);

include('header.php');
include('sidebar.php');

?>
<div class="content_b">
			<div class="main">
				<?php
				if ($result):
				?>
				<table>
					<tr> 
						<th>Tanggal</th>
						<th>Berita</th>
						<th>Nama</th>
						<th>Email</th>
						<th>Komentar</th>
						<th>Action</th>
					</tr>
					<?php while($row = mysqli_fetch_array($result)): ?>
					<tr>
						<td><?php echo date("j F Y", strtotime($row['tanggal'])); ?> </td>
						<td> <?php echo $row['id_berita']; ?> </td>
						<td> <?php echo $row['Nama']; ?></td>
						<td> <?php echo $row['email']; ?></td>
						<td><?php echo $row['komentar']; ?></td>
						
						<td class="center">
							<a class="btn btn-default" href="edit_k.php?id=<?php echo $row['id'];?>"> Edit </a>
							<a class="btn btn-alert" onclick="return confirm('Yakin akan menghapus data?');" 
								href="hapus.php?id=<?php echo $row['id'];?>"> Delete </a>
						</td>
					</tr>
				<?php endwhile; ?>
				</table>
				<?php endif; ?>
			</div>
		</div>
		<?php include_once 'footer.php'; ?>
