<!-- Membuat Konten -->
		<br>
		<div id="content">
		<h2 align="center"> Welcome to Administrator</h2>
		</div>
		<!-- Membuat footer -->