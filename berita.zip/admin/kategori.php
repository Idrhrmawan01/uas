<?php
include_once 'koneksi.php';
$title ='kategori';
$sql='SELECT * FROM kategori';
$result = mysqli_query($conn, $sql);

$sql='SELECT * FROM kategori';
$result = mysqli_query($conn, $sql);

$sql_count = " SELECT COUNT(*) FROM kategori";
		if (isset($sql_where)) {
			$sql .=$sql_where;
			$sql_count .= $sql_where;
		}
		$result_count = mysqli_query($conn, $sql_count);
		$count = 0;
		if ($result_count) {
			$r_data = mysqli_fetch_row($result_count);
			$count = $r_data[0];
		}

		$per_page=4;
		$num_page = ceil($count / $per_page);
		$limit = $per_page;
		if (isset($_GET['page'])) {
			$page = $_GET['page'];
			$offset = ($page - 1) * $per_page;

		} else {
			$offset = 0;
			$page = 1;
		}

		$sql .= " LIMIT {$offset}, {$limit}";
		$result = mysqli_query($conn, $sql);

include('header.php');
include('sidebar.php');
?>

<div class="content_a">
	<div class="daftar">
	<div class="main">
		<?php

		echo '<a href="form_kategori.php" class="btn btn-large"> Tambah kategori</a>';
		?>
		<table>
			<th> Nama Kategori </th>
			<th>Aksi</th>
			<?php while ($row =mysqli_fetch_array($result)):?> 
			<tr>
				<td> <?php echo $row['nm_kategori']; ?></td>
				<td>
					<a class="btn btn-default" href="edit_kategori.php?id=<?php echo $row['id_kategori'];?>">Edit</a>
					<a class="btn btn-alert" onclick="return confirm('Yakin akan Menghapus data?');"
					href="hapus_kategori.php?id=<?php echo $row['id_kategori'];?>">Delete</a>
				</td>
			</tr>
		<?php endwhile; ?>
		</table>
		<ul class="pagination">
      <?php
            if ($page == 1) { // Jika page adalah pake ke 1, maka disable link PREV
            ?>

                <li class="disabled"><a href="#">&laquo;</a></li>
            <?php
            } else { // Jika buka page ke 1
                $link_prev = ($page > 1) ? $page - 1 : 1;
            ?>

             <li><a href="kategori.php?page=<?php echo $page-1;?>">&laquo;</a></li>


            <?php
            }
            ?>

       <?php for ($i=1; $i <=$num_page; $i++) {
         $link = "?page={$i}";
         if (!empty($q)) $link .= "&q={$q}";
         $class = ($page == $i ? 'active' : '');
         echo "<li><a class=\"{$class}\" href=\"{$link}\">{$i}</a></li>";
                } ?>
                <?php
            // Jika page sama dengan jumlah page, maka disable link NEXT nya
            // Artinya page tersebut adalah page terakhir
            if ($page == $num_page) { // Jika page terakhir
            ?>
                <li class="disabled"><a href="#">&raquo;</a></li>

            <?php
            } else { // Jika bukan page terakhir
                $link_next = ($page < $num_page) ? $page + 1 : $num_page;
            ?>
               <li><a href="kategori.php?page=<?php echo $page+1;?>">&raquo;</a></li>

            <?php
            }
            ?>

              </ul>
	</div>
</div>
</div>
<?php
include('footer.php');
?>