<?php 
include_once 'koneksi.php';
error_reporting(E_ALL);

if (isset($_POST['submit'])) {
	$user =$_POST['username'];
	$password =$_POST['password'];
	$nama =$_POST['nama_admin'];

$sql = 'INSERT INTO admin (username,password,nama_admin) ';
	$sql .= "VALUE ('{$user}','{$password}','{$nama}')";
	$result = mysqli_query($conn, $sql);
	if(!$result) {
		die(mysqli_error($conn));
	}
	header('location: user.php');
}



include('header.php');
include('sidebar.php');

?>
<div class="content_a">
	<div class="daftar">
	<div class="main">
		
<br>
<h2>Tambah User</h2>
<form method="post" action="form_user.php" enctype="multipart/form-data">
	<div class="input">
		<input type="text" name="nama_admin" placeholder="Nama Admin" />
	</div>
	<div class="input">
		<input type="text" name="username" placeholder="Username" />
	</div>

	<div class="input">
		<input type="text" name="password" placeholder="password" />
	</div>
	<div class="submit">
		<input type="submit" name="submit" class="btn btn-large" value="simpan" />
	</div>
</form>
</div>
</div>
</div>
<?php 
include_once 'footer.php' ?>