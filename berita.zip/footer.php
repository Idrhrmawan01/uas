<!-- Membuat footer -->
		<footer>
			<p> &copy;2018, Teknik Informatika Pelita Bangsa</p>
		</footer>