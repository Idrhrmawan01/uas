<!-- Membuat sidebar -->
		<div class="sidebar">

			<div class="widget-box">
				<h3 class="title"> IDR'News</h3>
				<p> IDR'News adalah sebuah Web Berita sederhana yang menampilkan berita - berita terkini </p>
			</div>
		</div>