<!-- Membuat Konten -->
		<?php
		include 'koneksi.php';
		$title = ' Data Artikel';
		$sql= "SELECT * From berita";
		$result= mysqli_query($conn, $sql);

		$sql_count = " SELECT COUNT(*) FROM berita";
		if (isset($sql_where)) {
			$sql .=$sql_where;
			$sql_count .= $sql_where;
		}
		$result_count = mysqli_query($conn, $sql_count);
		$count = 0;
		if ($result_count) {
			$r_data = mysqli_fetch_row($result_count);
			$count = $r_data[0];
		}

		$per_page=2;
		$num_page = ceil($count / $per_page);
		$limit = $per_page;
		if (isset($_GET['page'])) {
			$page = $_GET['page'];
			$offset = ($page - 1) * $per_page;

		} else {
			$offset = 0;
			$page = 1;
		}

		$sql .= " LIMIT {$offset}, {$limit}";
		$result = mysqli_query($conn, $sql);
		
		?>

		<div id="content">	
			<div class="row">
				<div class="daftar">
				
				<?php while ($row= mysqli_fetch_array($result)): ?>
				<div>
					<td> <?php echo "<img src=\"admin/{$row['gambar']}\"/>"; ?> </td>
					<h3><?php echo $row['tittle'];  ?> </h3>
					<p><?php 
						$text=$row['content'];
						$potong_text=substr($text, 0, 300);
						echo $potong_text; ?> </p>
						<p><?php echo $row['tanggal']; ?> 
					<a href="view.php?id=<?php echo $row['id'];?>"> Baca Selengkapnya</a> </p>
					<br>
					<hr>
				</div>
			<?php endwhile; ?>
			<br>
			<ul class="pagination">
      <?php
            if ($page == 1) { // Jika page adalah pake ke 1, maka disable link PREV
            ?>

                <li class="disabled"><a href="#">&laquo;</a></li>
            <?php
            } else { // Jika buka page ke 1
                $link_prev = ($page > 1) ? $page - 1 : 1;
            ?>

             <li><a href="index.php?page=<?php echo $page-1;?>">&laquo;</a></li>


            <?php
            }
            ?>

       <?php for ($i=1; $i <=$num_page; $i++) {
         $link = "?page={$i}";
         if (!empty($q)) $link .= "&q={$q}";
         $class = ($page == $i ? 'active' : '');
         echo "<li><a class=\"{$class}\" href=\"{$link}\">{$i}</a></li>";
                } ?>
                <?php
            // Jika page sama dengan jumlah page, maka disable link NEXT nya
            // Artinya page tersebut adalah page terakhir
            if ($page == $num_page) { // Jika page terakhir
            ?>
                <li class="disabled"><a href="#">&raquo;</a></li>

            <?php
            } else { // Jika bukan page terakhir
                $link_next = ($page < $num_page) ? $page + 1 : $num_page;
            ?>
               <li><a href="index.php?page=<?php echo $page+1;?>">&raquo;</a></li>

            <?php
            }
            ?>

              </ul>


		</div>
		</div>
		</div>
