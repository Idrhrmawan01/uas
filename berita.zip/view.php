<?php
error_reporting(E_ALL);
include 'koneksi.php';
$title='Data Artikel';
$id=$_GET['id'];
$sql="SELECT * FROM berita Where id ='{$id}'";
$result =mysqli_query($conn, $sql);
if(!$result) die ('Error:Data Tidak Tersedia');
$data=mysqli_fetch_array($result);

function is_select($var, $val)  {
	if($var == $val ) return 'selected="selected"';
	return false;
}

if (isset($_POST['submit'])) {
	$nama =$_POST['nama'];
	$berita=$_POST['berita'];
	$email =$_POST['email'];
	$komentar =$_POST['komentar'];
	$tanggal=$_POST['tanggal'];


$sql = 'INSERT INTO komentar (nama,email,komentar,tanggal) ';
	$sql .= "VALUE ('{$nama}','{$email}','{$komentar}','{$tanggal}')";
	$result = mysqli_query($conn, $sql);
	if(!$result) {
		die(mysqli_error($conn));
	}
	header('location: view.php');
}

$sql='SELECT * FROM komentar order by tanggal DESC';
$result = mysqli_query($conn, $sql);

include_once 'header.php';



?>
<div class="content">
	<div class="row">
	<div class="main">
	<h3><?php echo $data['tittle'];  ?> </h3>
	<br>
	<p><?php echo $data['tanggal']; ?> </p>
	<hr>
	<td> <?php echo "<img src=\"admin/{$data['gambar']}\"/>"; ?> </td>
	<br>
	<p><?php echo $data['content']; ?></p>
	<br>
	
	<hr>
</div>
</div>
</div>

<div class="content">
	<div class="row">
		<div class="main">
	<h2>Tambahkan Komentar</h2>
		<form method="post" action="view.php" enctype="multipart/form-data">
		<div class="input">
			<label>Nama </label>
		<input type="text" name="nama" placeholder="Nama" />
	</div>
	<div class="input">
		<label>Email</label>
		<input type="text" name="email" placeholder="Email" />
	</div>
	<div class="input">
		<label>Komentar</label>
		<textarea type="text" name="komentar" cols="100" rows="20" placeholder="Komentar"></textarea>
	</div>
	
	<div class="submit">
		<input type="submit" name="submit" class="btn btn-large" value="simpan" />
	</div>
</form>

<?php while ($row = mysqli_fetch_array($result)): ?>
			<tr>
				<td>Komentar Oleh <?php echo $row['nama']; ?>, Pada tanggal <?php echo date("j F Y", strtotime($row['tanggal'])); ?> </td>
				<p> <?php echo $row['komentar']; ?> </p>
			<?php endwhile; ?>
</div>
</div>

</div>

<?php 
include_once 'footer.php';
 ?>

